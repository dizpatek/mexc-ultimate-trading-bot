// Matrix Pro Bridge V3.0 - Bypass Script
// Runs in MAIN world to override window properties
(function() {
    'use strict';
    
    try {
        const isTV = window.location.hostname.includes('tradingview.com');
        const isCryptoRank = window.location.hostname.includes('cryptorank.io');
        const isIframe = window.self !== window.top;
        
        if (isTV && isIframe) {
            try {
                Object.defineProperty(window, 'frameElement', { 
                    get: () => null,
                    configurable: true 
                });
            } catch {}
            
            try {
                Object.defineProperty(window, 'top', { 
                    get: () => window,
                    configurable: true 
                });
                Object.defineProperty(window, 'parent', { 
                    get: () => window,
                    configurable: true 
                });
            } catch {}
        }

        // Google SignIn interceptor
        if (isTV && !isIframe) {
            const checkGoogleButtons = setInterval(() => {
                const googleButtons = document.querySelectorAll('[data-google-signin], .google-signin, [onclick*="google"]');
                googleButtons.forEach(btn => {
                    if (btn.dataset.matrixEnhanced) return;
                    btn.dataset.matrixEnhanced = 'true';
                    btn.addEventListener('click', () => {
                        window.postMessage({
                            source: 'matrix-bridge-extension',
                            action: 'googleLoginClicked',
                            url: window.location.href
                        }, '*');
                    }, true);
                });
            }, 500);
            setTimeout(() => clearInterval(checkGoogleButtons), 10000);
        }

    } catch (e) {
        console.error('[Matrix Bridge Bypass] Error:', e);
    }
})();
